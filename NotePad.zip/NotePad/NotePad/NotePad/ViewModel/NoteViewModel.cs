﻿using NotePad.Commands;
using NotePad.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NotePad.ViewModel
{
    public class NoteViewModel : INotifyPropertyChanged
    {
        public Commands.AddCommand addCommand = new Commands.AddCommand();

        //public Commands.EditCommand editCommand = new Commands.EditCommand();
        public SaveCommand SaveCommand { get; }

        public event PropertyChangedEventHandler PropertyChanged;

        public ObservableCollection<Note> MyNoteList = new ObservableCollection<Note>();

        private List<Note> _allNotes = new List<Note>();

        public string _NoteName { get; set; }

        public string _NoteContent { get; set; }
       

        private Note _selectedNote;
        

        private string _filter;
        public NoteViewModel()
        {
            SaveCommand = new SaveCommand(this);

            addCommand.OnNoteCreated += AddCommand_OnNoteCreated;
            PerformFiltering();

        }
        protected virtual void RaisePropertyChanged(string propName)
        {
            if (PropertyChanged != null)
            {
                Task.Run(() => PropertyChanged(this, new PropertyChangedEventArgs(propName)));
            }
        }

        public string NoteContent
        {
            get { return _NoteContent; }
            set
            {

                _NoteContent = value;
                RaisePropertyChanged("Content");
            }
        }


        //This event fires when the addCommand object raises it's "A new Note was created" event.
        private void AddCommand_OnNoteCreated(object sender, EventArgs e)
        {
            //If a Note object exists, add it to the MyParty list
            if (addCommand.TheNote != null)
            {
                _allNotes.Add(addCommand.TheNote);
                MyNoteList.Add(addCommand.TheNote);
            }
        }

        private void EditCommand_OnNoteCreated(object sender, EventArgs e)
        {
            
        }
        private void SaveCommand_OnNoteCreated(object sender, EventArgs e)
        {
            if(SaveCommand.TheNote == null)
            {
                //Event to call the save functionality
                SaveCommand.FireCanExecuteChanged();
            }
            
        }

        public Note SelectedNote
        {
            get{return _selectedNote;}
            set
            {
                _selectedNote = value;
                if (value == null)
                {
                    //_NoteContent = "No Content available for this day.";
                    _NoteName = "Untitled Note";
                   
                }
                else
                {
                    _NoteContent = value.Content;
                    _NoteName = value.Name;

                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("_NoteName"));
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs("_NoteContent"));

                
            }
        }

        

        public string Filter
        {
            get { return _filter; }
            set
            {
                if (value == _filter) { return; }
                _filter = value;
                PerformFiltering();
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Filter)));
            }
        }

        private void PerformFiltering()
        {
            if (_filter == null)
            {
                _filter = "";
            }
            //If _filter has a value (ie. user entered something in Filter textbox)
            //Lower-case and trim string
            var lowerCaseFilter = Filter.ToLowerInvariant().Trim();

            //Use LINQ query to get all personmodel names that match filter text, as a list
            var result =
                _allNotes.Where(d => d.Name.ToLowerInvariant()
                .Contains(lowerCaseFilter))
                .ToList();

            //Get list of values in current filtered list that we want to remove
            //(ie. don't meet new filter criteria)
            var toRemove = MyNoteList.Except(result).ToList();

            //Loop to remove items that fail filter
            foreach (var x in toRemove)
            {
                MyNoteList.Remove(x);
            }

            var resultCount = result.Count;
            // Add back in correct order.
            for (int i = 0; i < resultCount; i++)
            {
                var resultItem = result[i];
                if (i + 1 > MyNoteList.Count || !MyNoteList[i].Equals(resultItem))
                {
                    MyNoteList.Insert(i, resultItem);
                }
            }
        }




    }
}
