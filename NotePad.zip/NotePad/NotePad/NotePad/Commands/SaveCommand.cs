﻿using NotePad.Models;
using NotePad.UserControls;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.UI.Xaml.Controls;

namespace NotePad.Commands
{
    public class SaveCommand : ICommand
    {
        public event EventHandler CanExecuteChanged;
        private ViewModel.NoteViewModel nvm;

        public Note TheNote { get; set; }

        public SaveCommand(ViewModel.NoteViewModel nvm)
        {
            this.nvm = nvm;
        }

        public bool CanExecute(object parameter)
        {
            return nvm.SelectedNote == null;
        }

        public async void Execute(object parameter)
        {
            AddNewNoteDialog snd = new AddNewNoteDialog();
            ContentDialogResult result = await snd.ShowAsync();

            if (result == ContentDialogResult.Primary)
            {
                try
                {
                    Repositories.NoteRepo.SaveNoteToFile(snd, nvm._NoteContent);
                    ContentDialog savedDialog = new ContentDialog()
                    {
                        Title = "Save Successful",
                        Content = "Names saved successfully to file, hurray!",
                        PrimaryButtonText = "OK"
                    };
                    await savedDialog.ShowAsync();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine("Error when saving to file");
                }
            }
        }
        public void FireCanExecuteChanged()
        {
            CanExecuteChanged?.Invoke(this, EventArgs.Empty);
        }
    }
}
