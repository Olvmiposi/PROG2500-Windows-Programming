﻿using NotePad.Models;
using NotePad.UserControls;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.UI.Xaml.Controls;

namespace NotePad.Commands
{
    public class AddCommand : ICommand
    {
        public Note TheNote { get; set; }

        public event EventHandler CanExecuteChanged;
        

        //Create an event and delegate (ie. handler), to raise an event when a new char is created.
        public event CharCreatedHandler OnNoteCreated;
        public delegate void CharCreatedHandler(object sender, EventArgs e);

        public bool CanExecute(object parameter)
        {
            return true;
        }

        public async void Execute(object parameter)
        {
            //Pop up a dialog to gather Note information.
            AddNewNoteDialog addNewNoteDialog = new AddNewNoteDialog();
            ContentDialogResult result = await addNewNoteDialog.ShowAsync();

            if (result == ContentDialogResult.Primary)
            {
                //Instantiate as an object, save to collection.
                TheNote = addNewNoteDialog.Note;

                //Raise the "a new note was created event, so listener classes (ie. ViewModel) are made aware.
                OnNoteCreated?.Invoke(this, new EventArgs());

            }
        }       
    }
}
