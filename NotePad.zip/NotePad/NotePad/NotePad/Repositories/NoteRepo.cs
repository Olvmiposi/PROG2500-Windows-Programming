﻿using NotePad.Models;
using NotePad.UserControls;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Storage;

namespace NotePad.Repositories
{
    public class NoteRepo
    {
        private static StorageFolder notesFolder = ApplicationData.Current.LocalFolder;
        //AddNewNoteDialog snd = new AddNewNoteDialog();

        public async static void SaveNoteToFile(AddNewNoteDialog snd, String userNote)            
        {
      
            String fileName = snd.Name + ".txt";
            //String filecontent = dialog.ContentText;
            try
            {
                //await File.WriteAllTextAsync(fileName, userNote);
                StorageFile noteFile = await notesFolder.CreateFileAsync(fileName,
                    CreationCollisionOption.OpenIfExists);
                //File.WriteAllText(noteFile, fileName);

                await Windows.Storage.FileIO.AppendTextAsync(noteFile, "Today's file: "
                    + snd.Name + " NOTES: " + userNote);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Oh noes! An error occurred with file writing. Ahhhhh!");
            }
        }
    }
}
