﻿using NotePad.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Content Dialog item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace NotePad.UserControls
{
    public sealed partial class AddNewNoteDialog : ContentDialog
    {
        //public ViewModel.NoteViewModel nvm { get; set; }
        public Note Note;
        public AddNewNoteDialog()
        {
            this.InitializeComponent();
            //nvm = new ViewModel.NoteViewModel();
            //this.DataContext = nvm;
        }
        public string ContentText
        {
            get { return ContentTextbox.Text; }
            //set { NameTextbox.Text = value; }
        }
        public string NameText
        {
            get { return NameTextbox.Text; }
            //set { NameTextbox.Text = value; }
        }

        private void ContentDialog_PrimaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            Note = new Note(NameTextbox.Text, ContentTextbox.Text);
        }

        private void ContentDialog_SecondaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {

        }
    }
}
